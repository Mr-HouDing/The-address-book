//
//  DetailViewController.m
//  通讯录3.1
//
//  Created by lanou3g on 15/9/22.
//  Copyright (c) 2015年 侯仁杰. All rights reserved.
//

#import "DetailViewController.h"
#import "LTView.h"

@interface DetailViewController ()<UINavigationControllerDelegate, UIImagePickerControllerDelegate, UIActionSheetDelegate>

@property (nonatomic, strong) LTView *nameView;
@property (nonatomic, strong) LTView *ageView;
@property (nonatomic, strong) LTView *sexView;
@property (nonatomic, strong) LTView *phoneView;
@property (nonatomic, strong) UITextView *contentView;
@property (nonatomic, strong) UIButton *imageButton;

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationController.navigationBar.translucent = NO;
    [self loadLTView];
}

- (void)loadLTView
{
    // 布局
    self.imageButton = [UIButton buttonWithType:(UIButtonTypeCustom)];
    self.imageButton.frame = CGRectMake(self.view.frame.size.width / 2 - 50, 10, 100, 100);
    self.imageButton.backgroundColor = [UIColor grayColor];
    [self.imageButton setTitle:@"选取照片" forState:(UIControlStateNormal)];
    [self.imageButton addTarget:self action:@selector(imageButtonClicked:) forControlEvents:(UIControlEventTouchUpInside)];
    [self.view addSubview:self.imageButton];
    
    self.nameView = [[LTView alloc] initWithFrame:CGRectMake(10, 110, self.view.frame.size.width - 20, 30)];
    self.nameView.label.text = @"姓名";
    self.nameView.textField.placeholder = @"请输入姓名";
    self.nameView.textField.text = self.model.name;
    [self.view addSubview:self.nameView];
    
    self.ageView = [[LTView alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(self.nameView.frame) + 10, self.view.frame.size.width - 20, 30)];
    self.ageView.label.text = @"年龄";
    self.ageView.textField.placeholder = @"请输入年龄";
    self.ageView.textField.text = self.model.age;
    [self.view addSubview:self.ageView];
    
    self.sexView = [[LTView alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(self.ageView.frame) + 10, self.view.frame.size.width - 20, 30)];
    self.sexView.label.text = @"性别";
    self.sexView.textField.placeholder = @"请输入性别";
    self.sexView.textField.text = self.model.sex;
    [self.view addSubview:self.sexView];
    
    self.phoneView = [[LTView alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(self.sexView.frame) + 10, self.view.frame.size.width - 20, 30)];
    self.phoneView.label.text = @"电话";
    self.phoneView.textField.placeholder = @"请输入电话";
    self.phoneView.textField.text = self.model.phone;
    [self.view addSubview:self.phoneView];
    
    self.contentView = [[UITextView alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(self.phoneView.frame) + 10, self.view.frame.size.width - 20, 150)];
    self.contentView.backgroundColor = [UIColor greenColor];
    self.contentView.alpha = 0.3;
    self.contentView.text = self.model.content;
    [self.view addSubview:self.contentView];
    
    UIButton *saveButton = [UIButton buttonWithType:(UIButtonTypeCustom)];
    saveButton.frame = CGRectMake(10, CGRectGetMaxY(self.contentView.frame) + 10, self.view.frame.size.width - 20, 30);
    [saveButton setTitle:@"保存" forState:(UIControlStateNormal)];
    saveButton.backgroundColor = [UIColor blueColor];
    saveButton.layer.cornerRadius = 3.0f;
    [saveButton addTarget:self action:@selector(setButtonCilcked:) forControlEvents:(UIControlEventTouchUpInside)];
    [self.view addSubview:saveButton];
}

// save按钮点击事件
- (void)setButtonCilcked:(UIButton *)sender
{
    NSString *nameStr = self.nameView.textField.text;
    NSString *ageStr = self.ageView.textField.text;
    NSString *sexStr = self.sexView.textField.text;
    NSString *phoneStr = self.phoneView.textField.text;
    NSString *contentStr = self.contentView.text;
    AddressBookModel *model = [[AddressBookModel alloc] initWithName:nameStr Age:ageStr Sex:sexStr Phone:phoneStr Content:contentStr Image:nil];
    
    // 代理传值
    if (self.delegate && [self.delegate respondsToSelector:@selector(passValueToListVC:)] && [self.delegate respondsToSelector:@selector(changeValueToListVC:index:)])
    {
        if (self.model != nil)
        {
            [self.delegate changeValueToListVC:model index:self.index];
        }else
        {
            [self.delegate passValueToListVC:model];
        }
    }
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

// 图片处理
- (void)imageButtonClicked:(UIButton *)sender
{
    UIActionSheet *acton = [[UIActionSheet alloc] initWithTitle:@"选取照片" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"相机", @"相册", nil];
    [acton showFromRect:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) inView:self.view animated:YES];
}

- (void)setImagePickerController:(UIImagePickerControllerSourceType)scource
{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.sourceType = scource;
    imagePicker.delegate = self;
    [imagePicker setEditing:YES];
    imagePicker.allowsEditing = YES;
    // 模态推出视图
    [self presentViewController:imagePicker animated:YES completion:nil];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex)
    {
        case 0:
            [self setImagePickerController:(UIImagePickerControllerSourceTypeCamera)];
            break;
        case 1:
            [self setImagePickerController:(UIImagePickerControllerSourceTypeSavedPhotosAlbum)];
            break;
        default:
            break;
    }
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    [self.imageButton setImage:image forState:(UIControlStateNormal)];
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
