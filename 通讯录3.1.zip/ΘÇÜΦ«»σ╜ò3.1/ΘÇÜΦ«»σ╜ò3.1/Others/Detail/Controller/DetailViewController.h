//
//  DetailViewController.h
//  通讯录3.1
//
//  Created by lanou3g on 15/9/22.
//  Copyright (c) 2015年 侯仁杰. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddressBookModel.h"

@protocol DetailVCDelegae <NSObject>

- (void)passValueToListVC:(AddressBookModel *)passModel;

- (void)changeValueToListVC:(AddressBookModel *)passModel index:(NSInteger)index;

@end

@interface DetailViewController : UIViewController

@property (nonatomic, assign) id<DetailVCDelegae> delegate;

@property (nonatomic, strong) AddressBookModel *model;

@property (nonatomic, assign) NSInteger index;

@end
