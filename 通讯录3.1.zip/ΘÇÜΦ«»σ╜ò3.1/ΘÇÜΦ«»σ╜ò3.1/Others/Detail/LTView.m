//
//  LTView.m
//  通讯录3.1
//
//  Created by lanou3g on 15/9/22.
//  Copyright (c) 2015年 侯仁杰. All rights reserved.
//

#import "LTView.h"

@implementation LTView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        [self loadLTView];
    }
    return self;
}

- (void)loadLTView
{
    self.label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 40, 30)];
    self.label.layer.borderWidth = 0.5;
    self.label.font = [UIFont systemFontOfSize:15.0f];
    self.label.textAlignment = NSTextAlignmentLeft;
    [self addSubview:self.label];
    
    self.textField = [[UITextField alloc] initWithFrame:CGRectMake(50, 0, self.frame.size.width - 50, 30)];
    self.textField.layer.borderWidth = 0.5;
    self.textField.borderStyle = UITextBorderStyleRoundedRect;
    self.textField.font = [UIFont systemFontOfSize:15.0f];
    self.textField.textAlignment = NSTextAlignmentLeft;
    self.textField.delegate = self;
    [self addSubview:self.textField];
}

//按下Done按钮的调用方法，我们让键盘消失
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

@end
