//
//  AddressBookModel.h
//  通讯录3.1
//
//  Created by lanou3g on 15/9/22.
//  Copyright (c) 2015年 侯仁杰. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AddressBookModel : NSObject

@property (nonatomic, strong) NSData *image;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *age;
@property (nonatomic, copy) NSString *sex;
@property (nonatomic, copy) NSString *phone;
@property (nonatomic, copy) NSString *content;

- (instancetype)initWithName:(NSString *)name
                         Age:(NSString *)age
                         Sex:(NSString *)sex
                       Phone:(NSString *)phone
                     Content:(NSString *)content
                       Image:(NSData *)image;

@end
