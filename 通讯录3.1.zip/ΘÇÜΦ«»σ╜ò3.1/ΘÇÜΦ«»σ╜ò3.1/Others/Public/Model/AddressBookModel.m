//
//  AddressBookModel.m
//  通讯录3.1
//
//  Created by lanou3g on 15/9/22.
//  Copyright (c) 2015年 侯仁杰. All rights reserved.
//

#import "AddressBookModel.h"

@implementation AddressBookModel

- (instancetype)initWithName:(NSString *)name
                         Age:(NSString *)age
                         Sex:(NSString *)sex
                       Phone:(NSString *)phone
                     Content:(NSString *)content
                       Image:(NSData *)image
{
    self = [super init];
    if (self)
    {
        _name = name;
        _age = age;
        _sex = sex;
        _phone = phone;
        _content = content;
        _image = image;
    }
    return self;
}

@end
