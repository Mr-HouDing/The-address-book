//
//  ListViewController.m
//  通讯录3.1
//
//  Created by lanou3g on 15/9/22.
//  Copyright (c) 2015年 侯仁杰. All rights reserved.
//

#import "ListViewController.h"
#import "DetailViewController.h"
#import "ListTableViewCell.h"

@interface ListViewController ()<UITableViewDelegate, UITableViewDataSource, DetailVCDelegae>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) DetailViewController *detailVC;
@property (nonatomic, strong) NSMutableArray *dataArray;

@end

@implementation ListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:(UIBarButtonSystemItemEdit) target:self action:@selector(remove)];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:(UIBarButtonSystemItemAdd) target:self action:@selector(insert)];
    self.dataArray = [NSMutableArray array];
    [self loadTableView];
}

- (void)insert
{
    self.detailVC = [[DetailViewController alloc] init];
    self.detailVC.delegate = self;
    [self.navigationController pushViewController:self.detailVC animated:YES];
}

// 代理方法实现
- (void)passValueToListVC:(AddressBookModel *)passModel
{
    [self.dataArray addObject:passModel];
    [self.tableView reloadData];
}

- (void)changeValueToListVC:(AddressBookModel *)passModel index:(NSInteger)index
{
    [self.dataArray replaceObjectAtIndex:index withObject:passModel];
    [self.tableView reloadData];
}

// 删除点击方法
- (void)remove
{
    [self.tableView setEditing:!self.tableView.isEditing animated:YES];
}

// 是否可以删除
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

// 处理数据源
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.dataArray removeObjectAtIndex:indexPath.row];
    [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:(UITableViewRowAnimationLeft)];
}

- (void)loadTableView
{
    self.tableView = [[UITableView alloc] initWithFrame:self.view.frame style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *str = @"CELL";
    ListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:str];
    if (!cell)
    {
        cell = [[ListTableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:str];
    }
    cell.model = self.dataArray[indexPath.row];
    return cell;
}

// 自适应方法
- (CGFloat)stringHeightWithString:(NSString *)str fontSize:(CGFloat)fontSize contentSize:(CGSize)size
{
    // 第一个参数：代表最大的范围
    // 第二个参数：代表的是 是否考虑字体，是否考虑字号
    // 第三个参数：代表的是是用什么字体什么字号
    // 第四个参数：用不到，所以基本写成nil
    CGRect stringRect = [str boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:fontSize]} context:nil];
    return stringRect.size.height;
}

// cell的高度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    AddressBookModel *model = self.dataArray[indexPath.row];
    return 130 + [self stringHeightWithString:model.content fontSize:18 contentSize:CGSizeMake(self.view.frame.size.width - 20, 10000)];
}

// 点击cell
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DetailViewController *detail = [[DetailViewController alloc] init];
    detail.model = self.dataArray[indexPath.row];
    detail.index = indexPath.row;
    detail.delegate = self;
    [self.navigationController pushViewController:detail animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
