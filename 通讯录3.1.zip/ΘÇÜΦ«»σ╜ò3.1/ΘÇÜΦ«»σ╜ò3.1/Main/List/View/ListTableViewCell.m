//
//  ListTableViewCell.m
//  通讯录3.1
//
//  Created by lanou3g on 15/9/22.
//  Copyright (c) 2015年 侯仁杰. All rights reserved.
//

#import "ListTableViewCell.h"

@interface ListTableViewCell()

@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *ageLabel;
@property (nonatomic, strong) UILabel *sexLabel;
@property (nonatomic, strong) UILabel *phoneLabel;
@property (nonatomic, strong) UILabel *contentLabel;
@property (nonatomic, strong) UIImageView *headerImageView;

@end

@implementation ListTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        self.nameLabel = [[UILabel alloc] init];
        [self.contentView addSubview:self.nameLabel];
        
        self.ageLabel = [[UILabel alloc] init];
        [self.contentView addSubview:self.ageLabel];
        
        self.sexLabel = [[UILabel alloc] init];
        [self.contentView addSubview:self.sexLabel];
        
        self.phoneLabel = [[UILabel alloc] init];
        [self.contentView addSubview:self.phoneLabel];
        
        self.contentLabel = [[UILabel alloc] init];
        [self.contentView addSubview:self.contentLabel];
        
        self.headerImageView = [[UIImageView alloc] init];
        [self.contentView addSubview:self.headerImageView];
    }
    return self;
}

// 布局
- (void)layoutSubviews
{
    [super layoutSubviews];
    self.headerImageView.frame = CGRectMake(10, 10, 100, 100);
    self.nameLabel.frame = CGRectMake(120, 10, self.frame.size.width - 130, 20);
    self.ageLabel.frame = CGRectMake(120, CGRectGetMaxY(self.nameLabel.frame) + 10, self.frame.size.width - 130, 20);
    self.sexLabel.frame = CGRectMake(120, CGRectGetMaxY(self.ageLabel.frame) + 10, self.frame.size.width - 130, 20);
    self.phoneLabel.frame = CGRectMake(120, CGRectGetMaxY(self.sexLabel.frame) + 10, self.frame.size.width - 130, 20);
    self.contentLabel.frame = CGRectMake(10, CGRectGetMaxY(self.phoneLabel.frame) + 10, self.frame.size.width - 20, 20);
    self.contentLabel.numberOfLines = 0;
    [self.contentLabel sizeToFit];
}

// model
- (void)setModel:(AddressBookModel *)model
{
    self.nameLabel.text = model.name;
    self.ageLabel.text = model.age;
    self.sexLabel.text = model.sex;
    self.phoneLabel.text = model.phone;
    self.contentLabel.text = model.content;
}

@end
